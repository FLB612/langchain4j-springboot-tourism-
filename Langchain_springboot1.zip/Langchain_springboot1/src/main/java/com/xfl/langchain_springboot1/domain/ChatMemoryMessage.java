package com.xfl.langchain_springboot1.domain;
import lombok.Data;


@Data
public class ChatMemoryMessage {
    private Integer id;
    private String memoryId;
    private String message;
}
