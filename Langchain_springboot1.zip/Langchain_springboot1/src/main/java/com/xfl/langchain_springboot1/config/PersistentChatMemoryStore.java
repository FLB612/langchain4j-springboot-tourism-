package com.xfl.langchain_springboot1.config;

import com.xfl.langchain_springboot1.domain.ChatMemoryMessage;
import com.xfl.langchain_springboot1.mapper.ChatMemoryMessageMapper;
import dev.langchain4j.data.message.ChatMessage;
import dev.langchain4j.data.message.ChatMessageDeserializer;
import dev.langchain4j.data.message.ChatMessageSerializer;
import dev.langchain4j.store.memory.chat.ChatMemoryStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;


import java.util.List;
@Component
public class PersistentChatMemoryStore implements ChatMemoryStore {
    @Autowired
    private ChatMemoryMessageMapper chatMemoryMessageMapper;

    @Override
    public List<ChatMessage> getMessages(Object memoryId) {
        String messages = chatMemoryMessageMapper.getByMemoryId(memoryId.toString());
        List<ChatMessage> chatMessages = ChatMessageDeserializer.messagesFromJson(messages);
        return chatMessages;
    }

    @Transactional
    @Override
    public void updateMessages(Object memoryId, List<ChatMessage> messages) {
        String messagesJson = ChatMessageSerializer.messagesToJson(messages);
        ChatMemoryMessage chatMemoryMessage = new ChatMemoryMessage();
        chatMemoryMessage.setMemoryId(memoryId.toString());
        chatMemoryMessage.setMessage(messagesJson);
        if (chatMemoryMessageMapper.getByMemoryId(memoryId.toString()) != null) {
            chatMemoryMessageMapper.update(chatMemoryMessage);
        } else {
            chatMemoryMessageMapper.insert(chatMemoryMessage);
        }
    }

    @Transactional
    @Override
    public void deleteMessages(Object memoryId) {
        chatMemoryMessageMapper.deleteByMemoryId(memoryId.toString());
    }



}




