package com.xfl.langchain_springboot1.controller;

import com.xfl.langchain_springboot1.config.AIConfig;
import dev.langchain4j.community.model.dashscope.QwenChatModel;
import dev.langchain4j.community.model.dashscope.QwenStreamingChatModel;
import dev.langchain4j.model.chat.response.ChatResponse;
import dev.langchain4j.model.chat.response.StreamingChatResponseHandler;
import dev.langchain4j.service.TokenStream;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

import java.time.LocalDate;


@RestController
@RequestMapping("/ai")
public class ChatController {
    @Autowired
    QwenChatModel chatModel;

    @Autowired
    QwenStreamingChatModel streamingChatModel;

    @RequestMapping("/chat")//http://localhost:8081/ai/chat
    public String test(@RequestParam(defaultValue = "你是谁") String message) {
        String chat;//阿里千问
        chat = chatModel.chat(message);
        return chat;
    }

    //流式输出
    @RequestMapping(value = "/stream", produces = "text/stream;charset=UTF-8")//http://localhost:8081/ai/stream
    public Flux<String> streamchatfuc(@RequestParam(defaultValue = "你是谁") String message) {

        Flux<String> flux = Flux.create(fluxSink -> {


            streamingChatModel.chat(message, new StreamingChatResponseHandler() {
                @Override
                public void onPartialResponse(String partialResponse) {
                    fluxSink.next(partialResponse);
                }

                @Override
                public void onCompleteResponse(ChatResponse chatResponse) {
                    fluxSink.complete();
                }

                @Override
                public void onError(Throwable throwable) {
                    fluxSink.error(throwable);
                }
            });

        });
        return flux;
    }
    @Autowired

    AIConfig.Assistant assistant;//http://localhost:8081/ai/memory_chat

    @RequestMapping(value = "/memory_chat")//http://localhost:8081/ai/memory_stream_chat
    public String memorychat(@RequestParam(defaultValue = "我叫XFL") String message) {
        return assistant.chat(message);
    }
    //流式响应
    @RequestMapping(value = "/memory_stream_chat",produces ="text/stream;charset=UTF-8")
    public Flux<String> memoryStreamChat(@RequestParam(defaultValue="我是谁") String message, HttpServletResponse response) {
        TokenStream stream = assistant.stream(message);

        return Flux.create(sink -> {
            stream.onPartialResponse(s -> sink.next(s))
                    .onCompleteResponse(c -> sink.complete())
                    .onError(sink::error)
                    .start();

        });
    }

    @Autowired
    AIConfig.AssistantUnique assistantUnique;

    @RequestMapping(value="/memoryId_chat")//http://localhost:8081/ai/memoryId_chat
    public String memoryChat(@RequestParam(defaultValue="我是谁") String message, Integer userId){
        return assistantUnique.chat(userId,message);
    }

    @Autowired
    AIConfig.AssistantUnique assistantUniqueStore;


    @RequestMapping(value = "/memoryId_chat_mysql")//http://localhost:8081/ai/memoryId_chat_mysql
    public String memoryChatformysql(@RequestParam(defaultValue="我是谁") String message, Integer userId) {
        return assistantUniqueStore.chat(userId,message);
    }

    @RequestMapping(value = "/memoryId_stream_chat", produces = "text/stream;charset=UTF-8")//http://localhost:8081/ai/memoryId_stream_chat
    public Flux<String> memoryIdStreamChat(@RequestParam(defaultValue = "你好") String message,
                                           @RequestParam Integer userId) {
        String currentDate = LocalDate.now().toString();  // 注入日期
        TokenStream tokenStream = assistantUniqueStore.stream(userId, message, currentDate);

        return Flux.create(sink -> {
            tokenStream.onPartialResponse(s -> sink.next(s))
                    .onCompleteResponse(c -> sink.complete())
                    .onError(sink::error)
                    .start();
        });
    }

}






