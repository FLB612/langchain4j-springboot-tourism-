package com.xfl.langchain_springboot1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LangchainSpringboot1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
