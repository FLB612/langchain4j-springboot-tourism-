package com.xfl.langchain_springboot1.mapper;

import com.xfl.langchain_springboot1.domain.ChatMemoryMessage;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;



@Mapper
public interface ChatMemoryMessageMapper {
    String getByMemoryId(@Param("memoryId") String memoryId);

    void insert(ChatMemoryMessage chatMemory);

    void update(ChatMemoryMessage chatMemory);

    void deleteByMemoryId(@Param("memoryId") String memoryId);
}
