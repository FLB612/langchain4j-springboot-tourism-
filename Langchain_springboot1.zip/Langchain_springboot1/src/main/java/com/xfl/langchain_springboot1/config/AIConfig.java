package com.xfl.langchain_springboot1.config;


import dev.langchain4j.memory.ChatMemory;
import dev.langchain4j.memory.chat.ChatMemoryProvider;
import dev.langchain4j.memory.chat.MessageWindowChatMemory;
import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.chat.StreamingChatLanguageModel;
import dev.langchain4j.service.AiServices;
import dev.langchain4j.service.MemoryId;
import dev.langchain4j.service.TokenStream;
import dev.langchain4j.service.UserMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import dev.langchain4j.service.*;

@Configuration
public class AIConfig {
    public interface Assistant{
        String chat(String message);
        // 流式响应
        TokenStream stream(String message);
    }

    @Bean
    public Assistant assistant(ChatLanguageModel qwenchatModel, StreamingChatLanguageModel qwenstreamingchatModel) {
        //设置最大记录对话数,记忆
        ChatMemory chatMemory = MessageWindowChatMemory.withMaxMessages(10);

        Assistant assistant = AiServices
                .builder(Assistant.class)
                .chatLanguageModel(qwenchatModel)
                .streamingChatLanguageModel(qwenstreamingchatModel)
                .chatMemory(chatMemory)
                .build();
        return assistant;
    }

    public interface AssistantUnique {
        String chat(@MemoryId int memoryId, @UserMessage String userMessage);
        // 流式响应
        TokenStream stream(@MemoryId int memoryId, @UserMessage String userMessage);
        @SystemMessage("""
                您是“福州旅游规划小助手”，一款由 AI 驱动的本地旅游问答系统。
                请以专业、亲切、细致的语气与用户交流，尽量提供贴心、实用的建议。
                您正在通过在线聊天系统与用户互动，帮助他们了解福州的景点、线路、美食和出行建议等。
                在提供个性化推荐或制定旅游路线之前，请优先询问并获取用户的出行时间、人数、兴趣偏好（如历史、美食、自然风光等）。
                您可以根据本地知识资料（如景点介绍、路线推荐等）来回答用户问题。
                请始终使用中文进行交流。
                今天的日期是 {{current_date}}.
                """)
            //TokenStream stream(@MemoryId int memoryId, @UserMessage String userMessage,@V("current_date") String currentDate);
        TokenStream stream(@MemoryId int memoryId,
                           @UserMessage String userMessage,
                           @V("current_date") String currentDate);
    }

    @Bean
    public AssistantUnique assistantUnique(ChatLanguageModel qwenchatModel, StreamingChatLanguageModel qwenstreamingchatModel){
        AssistantUnique assistant = AiServices
                .builder(AssistantUnique.class)
                .chatLanguageModel(qwenchatModel)
                .streamingChatLanguageModel(qwenstreamingchatModel)
                .chatMemoryProvider(memoryId-> MessageWindowChatMemory.builder().maxMessages(10).id(memoryId).build())
                .build();
        return assistant;
    }

    @Autowired
    private PersistentChatMemoryStore store;

    @Bean
    public AssistantUnique assistantUniqueStore(ChatLanguageModel qwenChatModel,
                                                     StreamingChatLanguageModel qwenStreamingChatModel) {


        ChatMemoryProvider chatMemoryProvider = memoryId -> MessageWindowChatMemory.builder()
                .id(memoryId)
                .maxMessages(10)
                .chatMemoryStore(store)
                .build();

        AssistantUnique assistant = AiServices.builder(AssistantUnique.class)
                .chatLanguageModel(qwenChatModel)
                .streamingChatLanguageModel(qwenStreamingChatModel)
                .chatMemoryProvider(chatMemoryProvider)
                .build();
        return assistant;
    }

}
